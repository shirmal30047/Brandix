/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtusa.rpa.flex;

import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.TreeMap;
import java.util.TreeSet;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author elselapatha
 */
public class ClaimExceptionReport {

    @SuppressWarnings("CallToPrintStackTrace")
    public String getReport(String source_path, String template_path, String target_path) {
        System.out.println("----------------------Create Output Document----------------------");
        System.out.println("1. Start Fuction:" + new Date());
        try {
            String newFilePath = "";
            File sourceFile = new File(source_path);
            if (sourceFile.exists() && sourceFile.getAbsolutePath().toLowerCase().endsWith(".xlsx") && template_path.toLowerCase().endsWith(".xlsx")) {
                XSSFWorkbook source;
                XSSFWorkbook target;

                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(sourceFile))) {
                    source = new XSSFWorkbook(in);
                    System.out.println("2. Success: Get source file.");
                }
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(template_path))) {
                    target = new XSSFWorkbook(in);
                    System.out.println("3. Success: Get template file.");
                }

                XSSFSheet sourceSheet = source.getSheet("BEL-Claim Exception Procurement");// get source file sheet
                XSSFSheet targetSheet = target.getSheet("Detail");//get template sheet

//                create date cell style
                XSSFCreationHelper createHelper = target.getCreationHelper();
                XSSFCellStyle cellDateStyle = target.createCellStyle();
                cellDateStyle.setDataFormat(createHelper.createDataFormat().getFormat("MM/dd/yyyy"));
                cellDateStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
                cellDateStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
                cellDateStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
                cellDateStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);

//                create hilight cell style
                XSSFCellStyle cellHighlightStyle = target.createCellStyle();
                cellHighlightStyle.setFillForegroundColor(new XSSFColor(Color.RED));
                cellHighlightStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
                cellHighlightStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
                cellHighlightStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
                cellHighlightStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
                cellHighlightStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);

//                create bordered cell style
                XSSFCellStyle cellBorderStyle = target.createCellStyle();
                cellBorderStyle.setBorderBottom(XSSFCellStyle.BORDER_THIN);
                cellBorderStyle.setBorderTop(XSSFCellStyle.BORDER_THIN);
                cellBorderStyle.setBorderRight(XSSFCellStyle.BORDER_THIN);
                cellBorderStyle.setBorderLeft(XSSFCellStyle.BORDER_THIN);

                FormulaEvaluator evaluator = target.getCreationHelper().createFormulaEvaluator();

                Date today = new Date();
                sourceSheet.removeMergedRegion(20);
                sourceSheet.removeColumnBreak(20);
                Iterator<Row> rowIterator = sourceSheet.rowIterator();
                while (rowIterator.hasNext()) {
                    Row sourceRow = rowIterator.next();
                    if (sourceRow.getRowNum() > 4) {
                        Row targetRow = targetSheet.createRow(sourceRow.getRowNum() - 4);
                        Iterator<Cell> cellIterator = sourceRow.cellIterator();
                        while (cellIterator.hasNext()) {
                            Cell sourceCell = cellIterator.next();
                            Cell targetCell = targetRow.createCell((sourceCell.getColumnIndex() == 20) ? sourceCell.getColumnIndex() - 2 : sourceCell.getColumnIndex() - 1);
                            targetCell.setCellStyle(cellBorderStyle);
                            if (sourceCell.getColumnIndex() != 14) {
                                switch (sourceCell.getCellType()) {
                                    case Cell.CELL_TYPE_NUMERIC:
                                        targetCell.setCellValue(sourceCell.getNumericCellValue());
                                        break;
                                    case Cell.CELL_TYPE_STRING:
                                        targetCell.setCellValue(sourceCell.getStringCellValue());
                                        break;
                                }
                            } else {
                                String value = null;
                                switch (sourceCell.getCellType()) {
                                    case Cell.CELL_TYPE_NUMERIC:
                                        value = new DecimalFormat("########").format(sourceCell.getNumericCellValue());
                                        break;
                                    case Cell.CELL_TYPE_STRING:
                                        value = sourceCell.getStringCellValue();
                                        break;
                                }
                                targetCell.setCellValue(new SimpleDateFormat("yyyyMMdd").parse(value));
                                targetCell.setCellStyle(cellDateStyle);
                            }

                            if (sourceRow.getRowNum() == sourceSheet.getLastRowNum()) {
                                targetSheet.autoSizeColumn(targetCell.getColumnIndex());
                            }
                            if (sourceCell.getColumnIndex() == sourceRow.getLastCellNum() - 1) {
                                Cell targetTodayCell = targetRow.createCell(19);
                                Cell targetAgeCell = targetRow.createCell(20);
                                targetTodayCell.setCellValue(today);
                                targetTodayCell.setCellStyle(cellDateStyle);

                                targetAgeCell.setCellType(Cell.CELL_TYPE_FORMULA);
                                targetAgeCell.setCellFormula("NETWORKDAYS(N" + (targetRow.getRowNum() + 1) + ",T" + (targetRow.getRowNum() + 1) + ")");

                                switch (evaluator.evaluateFormulaCell(targetAgeCell)) {
                                    case Cell.CELL_TYPE_NUMERIC:
                                        Cell targetCommentCell = targetRow.createCell(21);
                                        targetCommentCell.setCellStyle(cellBorderStyle);
                                        double ageValue = targetAgeCell.getNumericCellValue();
                                        if (ageValue == 1) {
                                            targetCommentCell.setCellValue("New");
                                        } else if (ageValue > 1) {
                                            targetCommentCell.setCellValue("Repeat");
                                        }

                                        if (ageValue >= 7) {
                                            targetAgeCell.setCellStyle(cellHighlightStyle);
                                        }
                                        break;
                                }

                            }
                        }
                    }
                }

                System.out.println("4. Success: Sheet filled.");
                File newFile = new File(target_path + "Claim Exception Report " + new SimpleDateFormat("dd-MM-yyyy").format(new Date()) + ".xlsx");
                try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(newFile))) {
                    target.write(out);
                    System.out.println("5. Success: File is placed.");
                }
                newFilePath = newFile.getAbsolutePath();
            } else {
                System.out.println("---------------^^^^----------------");
                System.out.println("Exception: File Not Exit OR File Extenction are not Match.");
            }
            System.out.println("6. Finished:" + new Date());
            return newFilePath;
        } catch (IOException | ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public String getTableOfSummaryByState(String source_path) {
        System.out.println("----------------------Table of Summary----------------------");
        System.out.println("1. Start Fuction:" + new Date());
        try {
            final TreeSet<String> setOfstates = new TreeSet<>();
            final TreeMap<String, String> setOfMerchant = new TreeMap<>();
            final TreeMap<Integer, Integer> setOfAge = new TreeMap<>();
            final ArrayList<MerchantBean> merchants = new ArrayList<>();

            String text = "";
            File sourceFile = new File(source_path);
            if (sourceFile.exists() && sourceFile.getAbsolutePath().toLowerCase().endsWith(".xlsx")) {
                XSSFWorkbook source;
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(sourceFile))) {
                    source = new XSSFWorkbook(in);
                    System.out.println("2. Success: Get source file.");
                }

                XSSFSheet sourceSheet = source.getSheet("Detail");// get source file sheet

                Iterator<Row> rowIterator1 = sourceSheet.rowIterator();
                while (rowIterator1.hasNext()) {
                    Row row = rowIterator1.next();
                    if (row.getRowNum() > 0) {
                        setOfstates.add(row.getCell(18).getStringCellValue().trim());
                    }
                }

                for (String state : setOfstates) {

                    Iterator<Row> rowIterator2 = sourceSheet.rowIterator();
                    while (rowIterator2.hasNext()) {
                        Row row = rowIterator2.next();
                        if (row.getRowNum() > 0 && row.getCell(18).getStringCellValue().trim().toLowerCase().equals(state.trim().toLowerCase())) {
                            setOfMerchant.put(row.getCell(1).getStringCellValue().trim(), row.getCell(8).getStringCellValue().trim());
                            setOfAge.put(Integer.parseInt(new DecimalFormat("############").format(row.getCell(20).getNumericCellValue())), 0);
                        }
                    }
                    System.out.println("3. Success: Create List of Metchant.");

                    for (String merchantName : setOfMerchant.keySet()) {

                        int commentNew = 0;
                        int commentRepeat = 0;
                        TreeMap<Integer, Integer> countOfAge = (TreeMap<Integer, Integer>) setOfAge.clone();

                        Iterator<Row> rowIterator3 = sourceSheet.rowIterator();
                        while (rowIterator3.hasNext()) {
                            Row row = rowIterator3.next();
                            if (row.getCell(1).getStringCellValue().trim().toLowerCase().equals(merchantName.toLowerCase()) && row.getCell(18).getStringCellValue().trim().toLowerCase().equals(state.trim().toLowerCase())) {
                                switch (row.getCell(21).getStringCellValue().trim().toLowerCase()) {
                                    case "new":
                                        commentNew++;
                                        break;
                                    case "repeat":
                                        commentRepeat++;
                                        break;
                                }
                                int age = Integer.parseInt(new DecimalFormat("############").format(row.getCell(20).getNumericCellValue()));
                                countOfAge.replace(age, countOfAge.get(age) + 1);
                            }
                        }

                        MerchantBean merchant = new MerchantBean();
                        merchant.setBuyerDivision(setOfMerchant.get(merchantName));
                        merchant.setName(merchantName);
                        merchant.setCommentNew(commentNew);
                        merchant.setCommentReapeat(commentRepeat);
                        merchant.setCountOfAge(countOfAge);
                        merchants.add(merchant);

                    }
                    System.out.println("4. Success: Create Summary.");

                    text += "<table width='100%' cellspacing='0'>";
                    text += "<thead>";
                    text += "<tr style='background-color: #006666;color: #ffffff;'>";
                    text += "<th  style='border: 1px solid #000;height: 40px;font-size: 26px;text-align: left;padding-left: 20px;' colspan='4'><strong>Status: " + state + "</strong></th>";
                    text += "</tr>";
                    text += "<tr>";
                    text += "<th colspan='4' style='height: 5px;'></th>";
                    text += "</tr>";
                    text += "<tr style='background-color: #009966;'>";
                    text += "<th style='border: 1px solid #000; height: 25px;' rowspan='2'>Merchant Name</th>";
                    text += "<th style='border: 1px solid #000;border-left: none; height: 25px;'>Count Of PO Numbers</th>";
                    text += "<th style='border: 1px solid #000;border-left: none' rowspan='2' width='10%'>Comment</th>";
                    text += "<th style='border: 1px solid #000;border-left: none' rowspan='2' width='20%'>Buyer Division</th>";
                    text += "</tr>";
                    text += "<tr style='background-color: #009966;'>";
                    text += "<th style='border-right: 1px solid #000;border-bottom: 1px solid #000; height: 25px;padding: 0px;'>";
                    text += "<table width='100%' cellspacing='0'>";
                    text += "<thead>";
                    text += "<tr>";
                    for (Integer age : setOfAge.keySet()) {
                        text += "<th style='border-right: 1px solid #000;height: 25px;width:" + 88 / setOfAge.size() + "%;'>" + age + "</th>";
                    }
                    text += "<th style='width: 12%;'>Total</th>";
                    text += "</tr>";
                    text += "</thead>";
                    text += "</table>";
                    text += "</th>";
                    text += "</tr>";
                    text += "</thead>";
                    text += "<tbody>";
                    TreeMap<Integer, Integer> grandTotal = (TreeMap<Integer, Integer>) setOfAge.clone();
                    for (MerchantBean merchant : merchants) {
                        text += "<tr>";
                        text += "<td style='border: 1px solid #000;border-top: none;height: 25px;'>" + merchant.getName() + "</td>";
                        text += "<td style='border: 1px solid #000;border-left: none;border-top: none;padding: 0px;' valign='top'>";
                        text += "<table width='100%' cellspacing='0'>";
                        text += "<thead>";
                        text += "<tr>";
                        int total = 0;
                        for (Integer age : merchant.getCountOfAge().keySet()) {
                            text += "<th style='border-right: 1px solid #000;height: 25px;width:" + 88 / setOfAge.size() + "%;'>" + ((merchant.getCountOfAge().get(age) > 0) ? merchant.getCountOfAge().get(age) : "") + "</th>";
                            total += merchant.getCountOfAge().get(age);
                            grandTotal.replace(age, grandTotal.get(age) + merchant.getCountOfAge().get(age));
                        }
                        text += "<th style='width: 12%;'>" + total + "</th>";
                        text += "</tr>";
                        text += "</thead>";
                        text += "</table>";
                        text += "</td>";
                        text += "<td style='border: 1px solid #000;border-left: none;border-top: none;text-align:center;'>" + ((merchant.getCommentNew() > 0 && merchant.getCommentReapeat() > 0) ? merchant.getCommentNew() + " New , " + merchant.getCommentReapeat() + " Repeat" : (merchant.getCommentNew() == 0) ? "Repeat" : "New") + "</td>";
                        text += "<td style='border: 1px solid #000;border-left: none;border-top: none;'>" + merchant.getBuyerDivision() + "</td>";
                        text += "</tr>";
                    }

                    text += "<tr style='background-color: #92d7f8'>";
                    text += "<td style='border: 1px solid #000;height: 25px;'><strong>Grand Total</strong></td>";
                    text += "<td style='border: 1px solid #000;border-left: none;padding: 0px;'>";
                    text += "<table width='100%' cellspacing='0'>";
                    text += "<thead>";
                    text += "<tr>";
                    int total = 0;
                    for (Integer age : grandTotal.keySet()) {
                        text += "<th style='border-right: 1px solid #000;height: 25px;width:" + 88 / setOfAge.size() + "%;'>" + grandTotal.get(age) + "</th>";
                        total += grandTotal.get(age);
                    }

                    text += "<th style='width: 12%;'>" + total + "</th>";
                    text += "</tr>";
                    text += "</thead>";
                    text += "</table>";
                    text += "</td>";
                    text += "<td colspan='2' style='border: 1px solid #000;border-left: none;'></td>";
                    text += "</tr>";
                    text += "</tbody>";
                    text += "</table>";
                    text += "<br/>";
                    text += "<br/>";

                }
            } else {
                System.out.println("---------------^^^^----------------");
                System.out.println("Exception: File Not Exit OR File Extenction are not Match.");
            }
            System.out.println("5. Finished:" + new Date());
            return text;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

    @SuppressWarnings("CallToPrintStackTrace")
    public void writeVBScript(String source, String target) {
        String text = "";
        text += "Dim objXLApp, objXLWb, objXLWs\n";
        text += "Set objXLApp = CreateObject(\"Excel.Application\")\n";
        text += "'objXLApp.Visible = True\n";
        text += "Set objXLWb = objXLApp.Workbooks.Open(\"" + source + "\")\n";
        text += "objXLWb.RefreshAll\n";
        text += "Set objXLWs = objXLWb.Sheets(1)\n";
        text += "Set objTable = objXLWb.PivotTableWizard\n";
        text += "Set objField = objTable.PivotFields(\"Procurement Merchant\")\n";
        text += "objField.ShowDetail=False\n";

        text += "Dim pvt\n";
        text += "Dim pvtField,abc\n";
        text += "Dim notPrint,notActivated\n";

        text += "notActivated=false\n";
        text += "notPrint=false\n";

        text += "set pvt = objXLWs.PivotTables(\"PivotTable6\")\n";
        text += "set pvtField = pvt.PivotFields(\"Claim Status\")\n";

        text += "pvtField.PivotItems(\"(blank)\").Visible = False\n";
        text += "pvtField. _\n";
        text += "EnableMultiplePageItems = True\n";

        text += "objXLApp.ActiveWorkbook.Save\n";
        text += "objXLApp.ActiveWorkbook.Close\n";

        try {
            File dir = new File(target);
            dir.mkdirs();
            File file = new File(dir.getAbsoluteFile() + "/script.vbs");
            FileWriter fileWriter = new FileWriter(file);
            try (BufferedWriter out = new BufferedWriter(fileWriter)) {
                out.write(text);
            } finally {
                fileWriter.close();
                try {
                    Runtime.getRuntime().exec("wscript "+file.getAbsolutePath()).waitFor();
                } catch (IOException e) {
                    e.printStackTrace();
                }finally{
                    file.delete();
                }
            }
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
    }

}
