package com.virtusa.rpa.flex;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author elselapatha
 */
public class Excel {
    
    @SuppressWarnings("CallToPrintStackTrace")
    public String getSytleNumber(String path) {
        try {
            File file = new File(path);
            if (file.isFile() && (path.toLowerCase().endsWith(".xlsx") || path.toLowerCase().endsWith(".xlsm"))) {
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {

                    //create work book
                    XSSFWorkbook workbook = new XSSFWorkbook(in);
                    //get Sheet
                    XSSFSheet sheet = workbook.getSheet("BOM");
                    Cell cell = sheet.getRow(0).getCell(1);

                    switch (cell.getCellType()) {
                        case Cell.CELL_TYPE_NUMERIC:
                            return cell.getNumericCellValue() + "";
                        case Cell.CELL_TYPE_STRING:
                            return cell.getStringCellValue();
                    }

                }
            } else {
               return "This is not a Excel..";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Reading Fail....";
    }
    
     @SuppressWarnings("CallToPrintStackTrace")
    public String extractTabaleFromBOM(String path,String target) {
        try {
            File file = new File(path);

            if (file.isFile() && (path.toLowerCase().endsWith(".xlsx") || path.toLowerCase().endsWith(".xlsm"))) {
                System.out.println("..............file got it...............");
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
                    //create work book
                    XSSFWorkbook workbook = new XSSFWorkbook(in);
                    XSSFWorkbook tempBook = new XSSFWorkbook();
                    System.out.println(".............. create work book................");

                    //get Sheet
                    XSSFSheet sheet = workbook.getSheet("BOM");

                    //create sheet
                    XSSFSheet bomsheet = tempBook.createSheet("BOM");

                    //Iterate through each rows one by one
                    Iterator<Row> rowIterator = sheet.iterator();

                    int firstRow = 0;
                    int rowCount = 0;
                    int columnCount = 0;
                    boolean isSetFirstRow = false;
                    while (rowIterator.hasNext()) {
                        Row row = rowIterator.next();

                        //For each row, iterate through all the columns
                        Iterator<Cell> cellIterator1 = row.cellIterator();
                        Iterator<Cell> cellIterator2 = row.cellIterator();

                        int cellCount = 0;
                        if (!isSetFirstRow) {
                            while (cellIterator1.hasNext()) {
                                Cell cell = cellIterator1.next();
                                if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
                                    cellCount++;
                                }
                            }
                            if (cellCount > 10) {
                                firstRow = row.getRowNum();
                                isSetFirstRow = true;
                                columnCount = cellCount;
                            }
                        }
                        if (isSetFirstRow) {
                            Row newRow = bomsheet.createRow(rowCount++);
                            while (cellIterator2.hasNext()) {
                                Cell cell = cellIterator2.next();
                                if (row.getRowNum() == firstRow) {
                                    Cell headers = newRow.createCell(cell.getColumnIndex());
                                    headers.setCellValue(Headers.MAP.get(cell.getStringCellValue()));
                                } else if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
                                    Cell newCell = newRow.createCell(cell.getColumnIndex());

                                    switch (cell.getCellType()) {
                                        case Cell.CELL_TYPE_NUMERIC:
                                            newCell.setCellValue(cell.getNumericCellValue());
                                            break;
                                        case Cell.CELL_TYPE_STRING:
                                            newCell.setCellValue(cell.getStringCellValue());
                                            break;
                                    }
                                }
                            }
                            if (row.getRowNum() == firstRow) {
                                Row dataType = bomsheet.createRow(rowCount++);
                                int count = 0;
                                while (count < columnCount) {
                                    Cell newCell = dataType.createCell(count++);
                                    newCell.setCellValue("String");
                                }
                            }
                        }
                    }
                    File tempDir = new File(target);
                    if (!tempDir.exists()) {
                        tempDir.mkdirs();
                    }
                    File newFile=new File(tempDir.getAbsolutePath()+"\\"+((file.getName().toLowerCase().endsWith("xlsm")?file.getName().replace("xlsm", "xlsx"):file.getName())));
                            
                    try (FileOutputStream outputStream = new FileOutputStream(newFile)) {
                        tempBook.write(outputStream);
                    }
                    return newFile.getAbsolutePath();
                }
            } else {
                return "This is not a Excel..";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Unsuccess....";
    }

    public static void main(String[] args) {
        new Excel().extractTabaleFromBOM("C:\\Projects\\Test\\CEA189F6.xlsm", "C:\\temp\\abc");
    }
}
