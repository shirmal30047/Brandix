/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.virtusa.rpa.flex;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author rsdaseneviratne
 */
public class ExcessRMReport {
    
    @SuppressWarnings("CallToPrintStackTrace")
    public String extractTabaleFromBOM(String path,String target) {
        try {
            File file = new File(path);
           File[] execlFiles = file.listFiles((File dir, String name) -> name.trim().toLowerCase().contains("excess rm report")  && name.endsWith(".xlsx"));
            if (execlFiles.length!=0) {
                System.out.println("..............file got it...............");
                System.out.println(execlFiles.length);
                try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(file))) {
                    //create work book
                    XSSFWorkbook workbook = new XSSFWorkbook(in);
                    XSSFWorkbook tempBook = new XSSFWorkbook();
                    System.out.println(".............. create work book................");

                    //get Sheet
                    XSSFSheet sheet = workbook.getSheet("Sheet1");

                    //create sheet
                    XSSFSheet bomsheet = tempBook.createSheet("Sheet1");

                    //Iterate through each rows one by one
                    Iterator<Row> rowIterator = sheet.iterator();

                    int firstRow = 0;
                    int rowCount = 0;
                    int columnCount = 0;
                    boolean isSetFirstRow = true;
                    while (rowIterator.hasNext()) {
                        Row row = rowIterator.next();

                        //For each row, iterate through all the columns
                        Iterator<Cell> cellIterator1 = row.cellIterator();
                        Iterator<Cell> cellIterator2 = row.cellIterator();

                        int cellCount = 0;
                        
                        if (isSetFirstRow) {
                            Row newRow = bomsheet.createRow(rowCount++);
                            while (cellIterator2.hasNext()) {
                                Cell cell = cellIterator2.next();
                                if (row.getRowNum() == firstRow) {
                                    Cell headers = newRow.createCell(cell.getColumnIndex());
                                    headers.setCellValue(Headers.MAP.get(cell.getStringCellValue()));
                                } else if (cell.getCellType() != Cell.CELL_TYPE_BLANK) {
                                    Cell newCell = newRow.createCell(cell.getColumnIndex());

                                    switch (cell.getCellType()) {
                                        case Cell.CELL_TYPE_NUMERIC:
                                            newCell.setCellValue(cell.getNumericCellValue());
                                            break;
                                        case Cell.CELL_TYPE_STRING:
                                            newCell.setCellValue(cell.getStringCellValue());
                                            break;
                                    }
                                }
                            }
                            if (row.getRowNum() == firstRow) {
                                Row dataType = bomsheet.createRow(rowCount++);
                                int count = 0;
                                while (count < columnCount) {
                                    Cell newCell = dataType.createCell(count++);
                                    newCell.setCellValue("String");
                                }
                            }
                        }
                    }
                    File tempDir = new File(target);
                    if (!tempDir.exists()) {
                        tempDir.mkdirs();
                    }
                    File newFile=new File(tempDir.getAbsolutePath()+"\\"+((file.getName().toLowerCase().endsWith("xlsm")?file.getName().replace("xlsm", "xlsx"):file.getName())));
                            
                    try (FileOutputStream outputStream = new FileOutputStream(newFile)) {
                        tempBook.write(outputStream);
                    }
                    return newFile.getAbsolutePath();
                }
                catch(Exception e){
                    System.out.println(e.getMessage());
                }
            } else {
                return "This is not a Excel..";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "Unsuccess....";
    }
     public static void main(String[] args) {
         System.out.println("test");
        String result= new ExcessRMReport().extractTabaleFromBOM("C:\\Projects\\", "C:\\Projects\\New folder");
    }
}
