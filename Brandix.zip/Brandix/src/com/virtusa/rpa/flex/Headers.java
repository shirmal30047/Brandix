/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtusa.rpa.flex;

import java.util.HashMap;

/**
 *
 * @author elselapatha
 */
public class Headers {
    public final static HashMap<String, String> MAP=new HashMap<>();
    static {
        MAP.put("MAIN CATEGORY (PRODUCT GROUP)", "MAIN_CATEGORY");
        MAP.put("RM PROCUREMENT GROUP", "RM_PROCUREMENT_GROUP");
        MAP.put("Item Name (Shortened Description within 30 digits) Please give a Recognisable Name for the Material", "Item_Name");
        MAP.put("ITEM DESCRIPTION\n(Max character limit = 60)", "ITEM_DESCRIPTION");
        MAP.put("ITEM CATEGORIZATION", "ITEM_CATEGORIZATION");
        MAP.put("GARMENT Z FTR", "GARMENT_Z_FTR");
        MAP.put("GARMENT CLR", "GARMENT_CLR");
        MAP.put("GARMENT SIZE", "GARMENT_SIZE");
        MAP.put("Order quantity", "Order_quantity");
        MAP.put("Requirement", "Requirement");
        MAP.put("RM Z FTR", "RM_Z_FTR");
        MAP.put("RM CLR", "RM_CLR");
        MAP.put("RM SIZE", "RM_SIZE");
        MAP.put("YY (Max character limit = 6 decimal places)", "YY");
        MAP.put("WASTAGE %", "WASTAGE");
        MAP.put("Supplier Nomination Status", "Supplier_Nomination_Status");
        MAP.put("SKU UOM", "SKU_UOM");
        MAP.put("PURCHASE UOM", "PURCHASE_UOM");
        MAP.put("CONVERSION", "CONVERSION");
        MAP.put("PURCHASE PRICE\n(Max character limit = 6 decimal places)", "PURCHASE_PRICE");
        MAP.put("HIERARCHY ID", "HIERARCHY_ID");
        MAP.put("FREIGHT\n(Max character limit = 4 decimal places)", "FREIGHT");
        MAP.put("TC\n(Max character limit = 4 decimal places) ", "TC");
        MAP.put("MOQ", "MOQ");
        MAP.put("ORDER MULTIPLE", "ORDER_MULTIPLE");
        MAP.put("Item Horizon for Demand Consolidation", "Item_Horizon_for_Demand_Consolidation");
        MAP.put("SUPP TOL %", "SUPP_TOL");
        MAP.put("SUPPLIER", "SUPPLIER");
        MAP.put("MANUFACTURING LEAD TIME (DAYS)", "MANUFACTURING_LEAD_TIME");
        MAP.put("MODE OF SHIPMENT", "MODE_OF_SHIPMENT");
        MAP.put("DELIVERY TERMS", "DELIVERY_TERMS");
        MAP.put("BUYER \n(SOURCING MERCHANT)", "BUYER");
    }
}
								