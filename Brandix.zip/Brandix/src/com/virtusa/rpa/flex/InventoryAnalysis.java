/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtusa.rpa.flex;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author elselapatha
 */
public class InventoryAnalysis {

    /**
     * this method generate excel file. input file accept only xlsx format input
     * files are closed style stocks and apl-reason analysis for leftover stock
     * @param sourceFolder
     */
    @SuppressWarnings({"CallToPrintStackTrace", "UnusedAssignment"})
    public String closedStyleStock(String sourceFolder) {
        System.out.println("-----------------------Inventory Analysis----------------------");
        System.out.println("1.Start Proccess:" + new Date());
        try {
            File source = new File(sourceFolder);
            System.out.println("2.Success: Get Source Folder.");

            File closedStyle = null;
            File aplReason = null;

            System.out.println("3.Waiting: Check File is Folder.");
            if (source.isDirectory()) {
                System.out.println("4.Waiting: Filter Excel Files.");
                File[] execlFiles = source.listFiles((File dir, String name) -> (name.trim().toLowerCase().contains("closed style stock details") || name.trim().toLowerCase().contains("apl-reason analysis for leftover stock")) && name.endsWith(".xlsx"));
                if (execlFiles.length != 2) {
                    System.out.println("Please Copy Input Files..\n !informatin: only 2 Files.");
                } else {
                    System.out.println("5.Success: Assigen Files.");
                    for (File execlFile : execlFiles) {
                        if (execlFile.getName().trim().toLowerCase().contains("closed style stock detail")) {
                            closedStyle = execlFile;
                            System.out.println("6.Success: Resolve Closed Style.");
                        } else if (execlFile.getName().trim().toLowerCase().contains("apl-reason analysis for leftover stock")) {
                            aplReason = execlFile;
                            System.out.println("6.Success: Resolve Apl-Reason.");
                        }
                    }
                }

                if (closedStyle != null && aplReason != null) {
                    System.out.println("7.Success: create WorkBooks.");
                    XSSFWorkbook cs = null;
                    XSSFWorkbook apl = null;
                    try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(closedStyle))) {
                        cs = new XSSFWorkbook(in);
                    }
                    try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(aplReason))) {
                        apl = new XSSFWorkbook(in);
                    }

                    System.out.println("8.Success: Read detail sheet in Closed Style.");
                    XSSFSheet detailSheet = cs.getSheet("Detail");
                    Iterator<Row> rowIterator1 = detailSheet.rowIterator();
                    while (rowIterator1.hasNext()) {
                        Row row = rowIterator1.next();
                        if (row.getRowNum() > 7) {
                            Cell procument = row.getCell(11);
                            Cell totalQty = row.getCell(20);
                            Cell totalValue = row.getCell(38);
                            Cell writeOff = row.getCell(43);
                            writeOff.setCellType(Cell.CELL_TYPE_STRING);

                            switch (totalQty.getCellType()) {
                                case Cell.CELL_TYPE_NUMERIC:
                                    if (totalQty.getNumericCellValue() < 1) {
                                        writeOff.setCellValue("Not Significant");
                                    }
                                    break;
                            }

                            switch (procument.getCellType()) {
                                case Cell.CELL_TYPE_STRING:
                                    String value = procument.getStringCellValue().trim().toLowerCase();
                                    if (value.equals("fabric") || value.equals("lace") || value.equals("elastic")) {
                                        switch (totalValue.getCellType()) {
                                            case Cell.CELL_TYPE_NUMERIC:
                                                if (totalValue.getNumericCellValue() < 1) {
                                                    writeOff.setCellValue("Less than $ 1");
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                    }

                    XSSFSheet aplSheet = apl.getSheet("apl-reason analysis for leftove");
                    System.out.println("9.Success: start Check apl-reason analysis sheet");
                    Iterator<Row> rowIterator2 = detailSheet.rowIterator();
                    while (rowIterator2.hasNext()) {
                        Row row = rowIterator2.next();
                        if (row.getRowNum() > 7) {
                            Cell writeOff = row.getCell(43);
                            writeOff.setCellType(Cell.CELL_TYPE_STRING);
                            if (writeOff.getStringCellValue().equals("")) {
                                Cell item = row.getCell(2);
                                Iterator<Row> rowIterator = aplSheet.rowIterator();
                                while (rowIterator.hasNext()) {
                                    Row aplRow = rowIterator.next();

                                    if (aplRow.getRowNum() > 4 && aplRow.getCell(5) != null) {
                                        if (aplRow.getCell(5).getStringCellValue().equals(item.getStringCellValue())) {
                                            double excessOrdered = (aplRow.getCell(11).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(11).getNumericCellValue() : 0;
                                            double MORequirementNotIssued = (aplRow.getCell(13).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(13).getNumericCellValue() : 0;
                                            double excessReceivedQty = (aplRow.getCell(14).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(14).getNumericCellValue() : 0;
                                            double negativeRO = (aplRow.getCell(19).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(19).getNumericCellValue() : 0;
                                            HashMap<String, String> values = new HashMap<>();

                                            if (excessOrdered > MORequirementNotIssued && excessOrdered > excessReceivedQty && excessOrdered > negativeRO) {
                                                values.put("high", "Excess Ordered");
                                                if (MORequirementNotIssued > excessReceivedQty && MORequirementNotIssued > negativeRO) {
                                                    values.put("low", "MO Requirement Not Issued");
                                                } else if (excessReceivedQty > negativeRO) {
                                                    values.put("low", "Excess Received Qty");
                                                } else if (negativeRO > 0) {
                                                    values.put("low", "Negative RO");
                                                }
                                            } else if (MORequirementNotIssued > excessReceivedQty && MORequirementNotIssued > negativeRO) {
                                                values.put("high", "MO Requirement Not Issued");
                                                if (excessOrdered > excessReceivedQty && excessOrdered > negativeRO) {
                                                    values.put("low", "Excess Ordered");
                                                } else if (excessReceivedQty > negativeRO) {
                                                    values.put("low", "Excess Received Qty");
                                                } else if (negativeRO > 0) {
                                                    values.put("low", "Negative RO");
                                                }
                                            } else if (excessReceivedQty > negativeRO) {
                                                values.put("high", "Excess Received Qty");
                                                if (excessOrdered > MORequirementNotIssued && excessOrdered > negativeRO) {
                                                    values.put("low", "Excess Ordered");
                                                } else if (MORequirementNotIssued > negativeRO) {
                                                    values.put("low", "MO Requirement Not Issued");
                                                } else if (negativeRO > 0) {
                                                    values.put("low", "Negative RO");
                                                }
                                            } else if (negativeRO > 0) {
                                                values.put("high", "Negative RO");
                                                if (excessOrdered > MORequirementNotIssued && excessOrdered > excessReceivedQty) {
                                                    values.put("low", "Excess Ordered");
                                                } else if (MORequirementNotIssued > excessReceivedQty) {
                                                    values.put("low", "MO Requirement Not Issued");
                                                } else if (excessReceivedQty > 0) {
                                                    values.put("low", "Excess Received Qty");
                                                }
                                            }
                                            if (values.size() == 2) {
                                                String s="";
                                                if (values.values().contains("Excess Ordered")) {
                                                    s=(s.equals(""))?"Ordered More Than Requirement":s+", Ordered More Than Requirement";
                                                } 
                                                if (values.values().contains("MO Requirement Not Issued")) {
                                                    s=(s.equals(""))?"Due to wastage reduction/YY reduction":s+", Due to wastage reduction/YY reduction";
                                                } 
                                                if (values.values().contains("Excess Received Qty")) {
                                                   s=(s.equals(""))?"Excess Received":s+", Excess Received";
                                                } 
                                                if (values.values().contains("Negative RO")) {
                                                   s=(s.equals(""))?"System issue update pending/Manual Issues":s+", System issue update pending/Manual Issues";
                                                }
                                                writeOff.setCellValue(s);
                                            }
                                        }
                                    }

                                }
                            }
                            detailSheet.autoSizeColumn(writeOff.getColumnIndex());
                        }
                    }

                    System.out.println("10.Success: Write Out put in Closed Style.");
                    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(closedStyle))) {
                        cs.write(out);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "okay";
    }

    /**
     * this method generate excel file. input file accept only xlsx format input
     * files are completed style stocks and apl-reason analysis for leftover
     * stock
     *
     * @param sourceFolder
     */
    @SuppressWarnings({"CallToPrintStackTrace", "UnusedAssignment"})
    public String complteStyleStock(String sourceFolder) {
        System.out.println("-----------------------Inventory Analysis----------------------");
        System.out.println("1.Start Proccess:" + new Date());
        try {
            File source = new File(sourceFolder);
            System.out.println("2.Success: Get Source Folder.");

            File closedStyle = null;
            File aplReason = null;

            System.out.println("3.Waiting: Check File is Folder.");
            if (source.isDirectory()) {
                System.out.println("4.Waiting: Filter Excel Files.");
                File[] execlFiles = source.listFiles((File dir, String name) -> (name.trim().toLowerCase().contains("completed style stocks") || name.trim().toLowerCase().contains("apl-reason analysis for leftover stock")) && name.endsWith(".xlsx"));
                if (execlFiles.length != 2) {
                    System.out.println("Please Copy Input Files..\n !informatin: only 2 Files.");
                } else {
                    System.out.println("5.Success: Assigen Files.");
                    for (File execlFile : execlFiles) {
                        if (execlFile.getName().trim().toLowerCase().contains("completed style stocks")) {
                            closedStyle = execlFile;
                            System.out.println("6.Success: Resolve Closed Style.");
                        } else if (execlFile.getName().trim().toLowerCase().contains("apl-reason analysis for leftover stock")) {
                            aplReason = execlFile;
                            System.out.println("6.Success: Resolve Apl-Reason.");
                        }
                    }
                }

                if (closedStyle != null && aplReason != null) {
                    System.out.println("7.Success: create WorkBooks.");
                    @SuppressWarnings("UnusedAssignment")
                    XSSFWorkbook cs = null;
                    @SuppressWarnings("UnusedAssignment")
                    XSSFWorkbook apl = null;
                    try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(closedStyle))) {
                        cs = new XSSFWorkbook(in);
                    }
                    try (BufferedInputStream in = new BufferedInputStream(new FileInputStream(aplReason))) {
                        apl = new XSSFWorkbook(in);
                    }

                    System.out.println("8.Success: Read detail sheet in Closed Style.");
                    XSSFSheet detailSheet = cs.getSheet("Detail");
                    Iterator<Row> rowIterator1 = detailSheet.rowIterator();
                    while (rowIterator1.hasNext()) {
                        Row row = rowIterator1.next();
                        if (row.getRowNum() > 5) {
                            Cell procument = row.getCell(9);
                            Cell totalQty = row.getCell(18);
                            Cell totalValue = row.getCell(20);
                            Cell writeOff = row.getCell(29);
                            writeOff.setCellType(Cell.CELL_TYPE_STRING);
                            switch (totalQty.getCellType()) {
                                case Cell.CELL_TYPE_NUMERIC:
                                    if (totalQty.getNumericCellValue() < 1) {
                                        writeOff.setCellValue("Not Significant");
                                    }
                                    break;
                            }

                            switch (procument.getCellType()) {
                                case Cell.CELL_TYPE_STRING:
                                    String value = procument.getStringCellValue().trim().toLowerCase();
                                    if (value.contains("fabric") || value.contains("lace") || value.contains("elastic")) {
                                        switch (totalValue.getCellType()) {
                                            case Cell.CELL_TYPE_NUMERIC:
                                                if (totalValue.getNumericCellValue() < 1) {
                                                    writeOff.setCellValue("Less than $ 1");
                                                }
                                                break;
                                        }
                                    }
                                    break;
                            }
                        }
                    }

                    XSSFSheet aplSheet = apl.getSheet("apl-reason analysis for leftove");
                    HashMap<String, Record> records = new HashMap<>();
                    Iterator<Row> aplRowIterator = aplSheet.rowIterator();
                    while (aplRowIterator.hasNext()) {
                        Row aplRow = aplRowIterator.next();

                        if (aplRow.getRowNum() > 4 && aplRow.getCell(5) != null) {
                            double excessOrdered = (aplRow.getCell(11).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(11).getNumericCellValue() : 0;
                            double MORequirementNotIssued = (aplRow.getCell(13).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(13).getNumericCellValue() : 0;
                            double excessReceivedQty = (aplRow.getCell(14).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(14).getNumericCellValue() : 0;
                            double negativeRO = (aplRow.getCell(19).getCellType() == Cell.CELL_TYPE_NUMERIC) ? aplRow.getCell(19).getNumericCellValue() : 0;

                            Record record = new Record();
                            record.setExcessOrdered(excessOrdered);
                            record.setMORequirementNotIssued(MORequirementNotIssued);
                            record.setNegativeRO(negativeRO);
                            record.setExcessReceivedQty(excessReceivedQty);
                            record.setItemNo(aplRow.getCell(5).getStringCellValue().toLowerCase());

                            records.put(aplRow.getCell(5).getStringCellValue().toLowerCase(), record);
                        }
                    }
                    System.out.println("9.Success: add apl records");

                    System.out.println("10.Success: start Check apl-reason analysis sheet");
                    Iterator<Row> rowIterator2 = detailSheet.rowIterator();
                    while (rowIterator2.hasNext()) {
                        Row row = rowIterator2.next();
                        if (row.getRowNum() > 5) {
                            Cell writeOff = row.getCell(29);
                            writeOff.setCellType(Cell.CELL_TYPE_STRING);
                            if (writeOff.getStringCellValue().equals("")) {
                                Cell item = row.getCell(12);

                                Record record = records.get(item.getStringCellValue().toLowerCase());
                                if (record != null) {
                                    double[] values = new double[4];
                                    values[0] = record.getExcessOrdered();
                                    values[1] = record.getMORequirementNotIssued();
                                    values[2] = record.getExcessReceivedQty();
                                    values[3] = record.getNegativeRO();

                                    Arrays.sort(values);

                                    double high = values[3];
                                    double low = values[2];

                                    if (high > 0 && low > 0) {
                                        String s="";
                                        if (high == record.getExcessOrdered() || low == record.getExcessOrdered()) {
                                           s=(s.equals(""))?"Ordered More Than Requirement":s+", Ordered More Than Requirement";
                                        }
                                        if (high == record.getMORequirementNotIssued() || low == record.getMORequirementNotIssued()) {
                                            s=(s.equals(""))?"Due to wastage reduction/YY reduction":s+", Due to wastage reduction/YY reduction";
                                        } 
                                        if (high == record.getExcessReceivedQty() || low == record.getExcessReceivedQty()) {
                                            s=(s.equals(""))?"Excess Received":s+", Excess Received";
                                        }
                                        if (high == record.getNegativeRO() || low == record.getNegativeRO()) {
                                            s=(s.equals(""))?"System issue update pending/Manual Issues":s+", System issue update pending/Manual Issues";
                                        }
                                        writeOff.setCellValue(s);
                                    }
                                }
                            }
                            detailSheet.autoSizeColumn(writeOff.getColumnIndex());
                        }
                    }
                    System.out.println("11.Success: Finish Check apl-reason analysis sheet");

                    System.out.println("12.Success: Write Out put in Closed Style.");
                    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(closedStyle))) {
                        cs.write(out);
                    }
                }
            }
            System.out.println("13.Finish Execution:" + new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return "Okay";
    }

    public static void main(String[] args) {
//        new InventoryAnalysis().closedStyleStock("C:\\Users\\rsdaseneviratne\\Desktop\\Inventory Analysis");
        new InventoryAnalysis().complteStyleStock("C:\\Users\\rsdaseneviratne\\Desktop\\Inventory Analysis");
    }
}
