/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtusa.rpa.flex;

import java.util.TreeMap;

/**
 *
 * @author elselapatha
 */
public class MerchantBean {
    private String name;
    private String buyerDivision;
    private int commentNew;
    private int commentReapeat;
    private TreeMap<Integer,Integer> countOfAge;

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the buyerDivision
     */
    public String getBuyerDivision() {
        return buyerDivision;
    }

    /**
     * @param buyerDivision the buyerDivision to set
     */
    public void setBuyerDivision(String buyerDivision) {
        this.buyerDivision = buyerDivision;
    }

    /**
     * @return the commentNew
     */
    public int getCommentNew() {
        return commentNew;
    }

    /**
     * @param commentNew the commentNew to set
     */
    public void setCommentNew(int commentNew) {
        this.commentNew = commentNew;
    }

    /**
     * @return the commentReapeat
     */
    public int getCommentReapeat() {
        return commentReapeat;
    }

    /**
     * @param commentReapeat the commentReapeat to set
     */
    public void setCommentReapeat(int commentReapeat) {
        this.commentReapeat = commentReapeat;
    }

    /**
     * @return the countOfAge
     */
    public TreeMap<Integer,Integer> getCountOfAge() {
        return countOfAge;
    }

    /**
     * @param countOfAge the countOfAge to set
     */
    public void setCountOfAge(TreeMap<Integer,Integer> countOfAge) {
        this.countOfAge = countOfAge;
    }
}
