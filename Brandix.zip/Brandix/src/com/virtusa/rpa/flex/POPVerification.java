/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.virtusa.rpa.flex;

import java.awt.Color;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFColor;
import org.apache.poi.xssf.usermodel.XSSFCreationHelper;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

/**
 *
 * @author rsdaseneviratne
 */
public class POPVerification {
    public String changeCellColour(String sourceFolder) {
        System.out.println("-----------------------POP Verification----------------------");
        System.out.println("1.Start Proccess:" + new Date());
        try {
            File source = new File(sourceFolder);
            System.out.println("2.Success: Get Source Folder.");

            File popVerification = null;
            File aplReason = null;

            System.out.println("3.Waiting: Check File is Folder.");
            if (source.isDirectory()) {
                System.out.println("4.Waiting: Filter Excel Files.");
                File[] execlFiles = source.listFiles((File dir, String name) -> name.trim().toLowerCase().contains("pop_verification")  && name.endsWith(".xlsx"));
                if (execlFiles.length != 1) {
                    System.out.println("Please Copy Input Files..\n !informatin: only 2 Files."+execlFiles.length );
                } else {
                    System.out.println("5.Success: Assigen "+execlFiles.length+"Files.");
                    for (File execlFile : execlFiles) {
                        if (execlFile.getName().trim().toLowerCase().contains("pop_verification")) {
                            popVerification = execlFile;
                            System.out.println("6.Success: Resolve pop_verification file. "+popVerification);
                        } 
                    }
                    
                }

                if (popVerification != null ) {
                    System.out.println("7.Success: create WorkBooks.");
                    XSSFWorkbook cs = null;
                    
                    try{
                        BufferedInputStream in = new BufferedInputStream(new FileInputStream(popVerification));
                        cs = new XSSFWorkbook(in);
                    }catch(Exception e){
                        System.out.println("Cannot Execute 8"+ e.getMessage());
                    }
                    

                    System.out.println("8.Success: Read detail sheet in Closed Style.");
                    XSSFSheet detailSheet = cs.getSheet("Sheet1");
                    
                    XSSFCellStyle cellRedHighlightStyle = cs.createCellStyle();
                cellRedHighlightStyle.setFillForegroundColor(new XSSFColor(Color.RED));
                cellRedHighlightStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
                
                XSSFCellStyle cellGreenHighlightStyle = cs.createCellStyle();
                cellGreenHighlightStyle.setFillForegroundColor(new XSSFColor(Color.GREEN));
                cellGreenHighlightStyle.setFillPattern(CellStyle.SOLID_FOREGROUND);
                
                
                    Iterator<Row> rowIterator1 = detailSheet.rowIterator();
                    if(rowIterator1.hasNext()){
                        rowIterator1.next();
                    }
                        
                        
                    while (rowIterator1.hasNext()) {
                        Row row = rowIterator1.next();
//                        System.out.println(row.getCell(13));
                        
                       // if (row.getRowNum() > 7) {
                           // Cell procument = row.getCell(11);
                            Cell totalQty = row.getCell(13);
                           // Cell totalValue = row.getCell(38);
                           // Cell writeOff = row.getCell(43);
                          //  writeOff.setCellType(Cell.CELL_TYPE_STRING);

                            switch (totalQty.getCellType()) {
                                case Cell.CELL_TYPE_STRING:
                                    if (Double.parseDouble(totalQty.toString()) >0) {
                                        totalQty.setCellStyle(cellRedHighlightStyle);
                                        //writeOff.setCellValue("Not Significant");
                                        //System.out.println("Change to red");
                                    }
                                    else
                                    {
                                        totalQty.setCellStyle(cellGreenHighlightStyle);
//                                        System.out.println("Change to green");
                                    }
                                    break;
                            }

                            
                      //  }
                    }
                       
                    

                    System.out.println("10.Success: Write Out put in Closed Style.");
                    try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(popVerification))) {
                        cs.write(out);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return "okay";
    }
    public static void main(String[] args) {
       // new InventoryAnalysis().closedStyleStock("C:\\Users\\rsdaseneviratne\\Desktop\\Inventory Analysis");
//        new POPVerification().changeCellColour("C:\\projects\\POP");
        new POPVerification().changeCellColour("C:\\projects\\");
    }
}
