/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.virtusa.rpa.flex;

/**
 *
 * @author elselapatha
 */
public class Record {

    private String itemNo;
    private double excessOrdered;
    private double MORequirementNotIssued;
    private double excessReceivedQty ;
    private double negativeRO;

    /**
     * @return the itemNo
     */
    public String getItemNo() {
        return itemNo;
    }

    /**
     * @param itemNo the itemNo to set
     */
    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    /**
     * @return the excessOrdered
     */
    public double getExcessOrdered() {
        return excessOrdered;
    }

    /**
     * @param excessOrdered the excessOrdered to set
     */
    public void setExcessOrdered(double excessOrdered) {
        this.excessOrdered = excessOrdered;
    }

    /**
     * @return the MORequirementNotIssued
     */
    public double getMORequirementNotIssued() {
        return MORequirementNotIssued;
    }

    /**
     * @param MORequirementNotIssued the MORequirementNotIssued to set
     */
    public void setMORequirementNotIssued(double MORequirementNotIssued) {
        this.MORequirementNotIssued = MORequirementNotIssued;
    }

    /**
     * @return the excessReceivedQty
     */
    public double getExcessReceivedQty() {
        return excessReceivedQty;
    }

    /**
     * @param excessReceivedQty the excessReceivedQty to set
     */
    public void setExcessReceivedQty(double excessReceivedQty) {
        this.excessReceivedQty = excessReceivedQty;
    }

    /**
     * @return the negativeRO
     */
    public double getNegativeRO() {
        return negativeRO;
    }

    /**
     * @param negativeRO the negativeRO to set
     */
    public void setNegativeRO(double negativeRO) {
        this.negativeRO = negativeRO;
    }
}
