/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package brandixwalisara;

import java.util.HashMap;

/**
 *
 * @author rsdaseneviratne
 */
public class Header {
    public final static HashMap<String, String> MAP=new HashMap<>();
    static {
        //Block Reference Mapping
        MAP.put("W H", "W_H");//
        MAP.put("Schedule Start Date", "Schedule_Start_Date");//
        MAP.put("Schedule Start Date", "Schedule_Start_Date");//
        MAP.put("Schedule ", "Schedule");//
        MAP.put("FG Color", "FG_Color");// 
        MAP.put("FG Size", "FG_Size");//
        MAP.put("Material Item Type", "Material_Item_Type");//
        MAP.put("Material Main Product", "Material_Main_Product");//
        MAP.put("Material Code", "Material_Code");//
        MAP.put("Mat Color", "Mat_Color");//

        MAP.put("Mat Size", "Mat_Size");//
        MAP.put("Required PO Qty", "Required_PO_Qty");//
        MAP.put("Purchase Price", "Purchase_Price");//
        MAP.put("Supplier", "Supplier");//
        MAP.put("Purchase W H", "Purchase_W_H");//
        MAP.put("Item Type", "Item_Type");//
        MAP.put("Cus Style", "Cus_Style");//
        MAP.put("FG Destination", "FG_Destination");//
        
    }
}
